package kfa.service;

import kfa.model.Book;

public class ShelfManager {
    public static int[] placeOnShelf(String[][] shelves, String isbn) {
        for (int i = 0; i < shelves.length; i++) {
            for (int j = 0; j < shelves[i].length; j++) {
                if (shelves[i][j].equals("")) {
                    shelves[i][j] = isbn;
                    return new int[]{i, j};
                }
            }
        }
        return new int[]{-1, -1};
    }

    public static void printShelves(String[][] shelves) {
        for (int i = 0; i < shelves.length; i++) {
            for (int j = 0; j < shelves[i].length; j++) {
                System.out.print((shelves[i][j].isEmpty() ? "[ ]" : shelves[i][j]) + " ");
            }
            System.out.println();
        }
    }

    public static Book findMostExpensive(Book[] books) {
        Book max = books[0];
        for (Book b : books) {
            if (b.getPrice() > max.getPrice()) max = b;
        }
        return max;
    }

    public static void reverseInPlace(Book[] books) {
        int n = books.length;
        for (int i = 0; i < n / 2; i++) {
            Book temp = books[i];
            books[i] = books[n - 1 - i];
            books[n - 1 - i] = temp;
        }
    }
}

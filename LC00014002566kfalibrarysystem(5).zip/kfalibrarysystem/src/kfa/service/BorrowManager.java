package kfa.service;

import kfa.model.Book;
import java.util.*;

public class BorrowManager {
    private HashSet<String> currentlyBorrowed = new HashSet<>();
    private HashMap<String, Book> isbnIndex = new HashMap<>();

    public boolean borrow(String isbn) {
        if (currentlyBorrowed.contains(isbn)) return false;
        currentlyBorrowed.add(isbn);
        return true;
    }

    public void returnBook(String isbn) {
        currentlyBorrowed.remove(isbn);
    }

    public void addToIndex(Book book) {
        isbnIndex.put(book.getIsbn(), book);
    }

    public Book findByIsbn(String isbn) {
        return isbnIndex.get(isbn);
    }

    public void mostBorrowedReport(String[] borrowLog) {
        HashMap<String, Integer> borrowFrequency = new HashMap<>();
        for (String title : borrowLog) {
            borrowFrequency.put(title, borrowFrequency.getOrDefault(title, 0) + 1);
        }
        String mostBorrowed = null;
        int max = 0;
        for (Map.Entry<String, Integer> entry : borrowFrequency.entrySet()) {
            if (entry.getValue() > max) {
                max = entry.getValue();
                mostBorrowed = entry.getKey();
            }
        }
        System.out.println("Most borrowed: " + mostBorrowed + " (" + max + " times)");
    }
}

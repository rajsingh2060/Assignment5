package kfa.service;

public class StringUtils {
    public static String sanitizeTitle(String raw) {
        raw = raw.trim();
        String[] words = raw.split("\\s+");
        StringBuilder sb = new StringBuilder();
        for (String w : words) {
            sb.append(Character.toUpperCase(w.charAt(0)))
                    .append(w.substring(1).toLowerCase())
                    .append(" ");
        }
        return sb.toString().trim();
    }

    public static String generateReceiptText(String memberName, kfa.model.LibraryItem item) {
        StringBuilder sb = new StringBuilder();
        sb.append("Member: ").append(memberName).append("\n");
        sb.append("Item: ").append(item.getTitle()).append("\n");
        sb.append("Due Date: [placeholder]\n");
        sb.append("-------------------------\n");
        return sb.toString();
    }

    public static void isbnComparisonDemo() {
        String s1 = "1234567890123";
        String s2 = new String("1234567890123");
        System.out.println("== result: " + (s1 == s2));
        System.out.println(".equals result: " + s1.equals(s2));
    }
}

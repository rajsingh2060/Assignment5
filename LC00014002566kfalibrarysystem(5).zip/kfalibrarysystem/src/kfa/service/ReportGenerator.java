package kfa.service;

import kfa.model.LibraryItem;

public class ReportGenerator {

    // D1. Member ID generator
    public static String generateMemberId(String fullName) {
        String[] parts = fullName.trim().split("\\s+");
        String first = parts[0];
        String last = (parts.length > 1) ? parts[1] : "XX"; // handle single-word names

        String firstPart = first.substring(0, Math.min(3, first.length())).toUpperCase();
        String lastPart = last.substring(0, Math.min(2, last.length())).toUpperCase();
        int randomNum = (int)(Math.random() * 900) + 100; // random 3-digit number

        return firstPart + lastPart + randomNum;
    }

    // D2. ISBN sanity check
    public static boolean isValidIsbn(String isbn) {
        if (isbn.length() != 13) return false;
        if (isbn.charAt(0) == '0') return false;
        for (int i = 0; i < isbn.length(); i++) {
            if (!Character.isDigit(isbn.charAt(i))) return false;
        }
        return true;
    }

    // D3. Catalogue report with StringBuilder
    public static String buildCatalogueReport(LibraryItem[] items, String keyword) {
        StringBuilder sb = new StringBuilder();
        sb.append("=== Catalogue Report ===\n");
        for (LibraryItem item : items) {
            if (item.getTitle().toLowerCase().contains(keyword.toLowerCase())) {
                sb.append(item.getTitle())
                        .append(" - ")
                        .append(item.isAvailable() ? "Available" : "Not Available")
                        .append("\n");
            }
        }
        return sb.toString();
    }
}

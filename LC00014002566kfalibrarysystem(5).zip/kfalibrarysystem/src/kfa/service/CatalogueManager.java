package kfa.service;

import kfa.model.LibraryItem;
import java.util.*;

public class CatalogueManager {
    private ArrayList<LibraryItem> catalogue = new ArrayList<>();
    private ArrayList<LibraryItem> removalHistory = new ArrayList<>();

    public void addItem(LibraryItem item) {
        catalogue.add(item);
    }

    public boolean removeItem(String isbn) {
        for (LibraryItem item : catalogue) {
            if (item.getIsbn().equals(isbn)) {
                catalogue.remove(item);
                removalHistory.add(item);
                return true;
            }
        }
        return false;
    }

    public ArrayList<LibraryItem> searchByTitle(String keyword) {
        ArrayList<LibraryItem> results = new ArrayList<>();
        for (LibraryItem item : catalogue) {
            if (item.getTitle().toLowerCase().contains(keyword.toLowerCase())) {
                results.add(item);
            }
        }
        return results;
    }

    public void sortByPrice() {
        Collections.sort(catalogue, Comparator.comparingDouble(LibraryItem::getPrice));
    }

    public void sortByTitle() {
        Collections.sort(catalogue, Comparator.comparing(LibraryItem::getTitle));
    }

    public void undoRemove() {
        if (!removalHistory.isEmpty()) {
            LibraryItem item = removalHistory.remove(removalHistory.size() - 1);
            catalogue.add(item);
            System.out.println("Undo successful: " + item.getTitle());
        } else {
            System.out.println("Nothing to undo.");
        }
    }

    public void printCatalogue() {
        for (LibraryItem item : catalogue) {
            System.out.println(item);
        }
    }
}

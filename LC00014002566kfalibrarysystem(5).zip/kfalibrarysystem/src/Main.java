import java.util.Arrays;
import kfa.model.Book;
import kfa.model.Magazine;
import kfa.model.DVD;
import kfa.model.LibraryItem;
import kfa.service.LibrarySystem;
import kfa.exception.BookNotAvailableException;
import kfa.exception.ItemOverdueException;
import kfa.service.StringUtils;
import kfa.service.ShelfManager;
import kfa.service.CatalogueManager;
import kfa.service.BorrowManager;
import kfa.service.ReportGenerator;

public class Main {
    public static void main(String[] args) {
        // =========================
        // Tutorial 4 – Section A
        // =========================
        System.out.println("=== Tutorial 4: Section A – Book Blueprint ===");
        Book b1 = new Book("Clean Code", "Robert Martin", "B001", 850);
        Book b2 = new Book("Effective Java", "Joshua Bloch", "B002", 950);
        Book b3 = new Book("Design Patterns", "GoF", "B003", 1200);
        Book b4 = new Book("Refactoring", "Martin Fowler", "B004", 800);

        Book[] books = {b1, b2, b3, b4};
        for (Book b : books) System.out.println(b);
        System.out.println("Total books: " + Book.getTotalBooks());

        // =========================
        // Tutorial 4 – Section B
        // =========================
        System.out.println("\n=== Tutorial 4: Section B – Inheritance & Interfaces ===");
        LibraryItem[] items = {
                b1,
                new Magazine("Time", "M001", 300, 45),
                new DVD("Inception", "D001", 500, 148)
        };
        for (LibraryItem item : items) {
            System.out.println(item);
            System.out.println("Lending period: " + item.getLendingPeriodDays() + " days");
        }

        // =========================
        // Tutorial 4 – Section C
        // =========================
        System.out.println("\n=== Tutorial 4: Section C – Exceptions & Packages ===");
        LibrarySystem system = new LibrarySystem();
        try {
            system.borrowItem(b1); // success
            system.borrowItem(b1); // triggers BookNotAvailableException
        } catch (BookNotAvailableException e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            System.out.println("Transaction processed for: " + b1.getTitle());
        }

        try {
            system.returnItem(b1, 0); // success
            system.returnItem(b1, 2); // triggers ItemOverdueException
        } catch (ItemOverdueException e) {
            System.out.println("Item overdue by " + e.getDaysOverdue() + " days.");
        } finally {
            System.out.println("Transaction processed for: " + b1.getTitle());
        }

        // =========================
        // Tutorial 4 – Section D
        // =========================
        System.out.println("\n=== Tutorial 4: Section D – Strings ===");
        String memberId = ReportGenerator.generateMemberId("Aarav Shrestha");
        System.out.println("Generated Member ID: " + memberId);

        System.out.println("Valid ISBN (1234567890123): " + ReportGenerator.isValidIsbn("1234567890123"));
        System.out.println("Invalid ISBN (too short): " + ReportGenerator.isValidIsbn("12345"));
        System.out.println("Invalid ISBN (letters): " + ReportGenerator.isValidIsbn("12345ABCDE678"));
        System.out.println("Invalid ISBN (starts with 0): " + ReportGenerator.isValidIsbn("0123456789123"));

        String report = ReportGenerator.buildCatalogueReport(items, "java");
        System.out.println(report);

        // =========================
        // Tutorial 5 – Section A
        // =========================
        System.out.println("\n=== Tutorial 5: Section A – String Utilities ===");
        System.out.println(StringUtils.sanitizeTitle(" the GREAT gatsby "));
        System.out.println(StringUtils.sanitizeTitle("   war   AND   PEACE "));
        System.out.println(StringUtils.sanitizeTitle("harry   potter"));
        System.out.println(StringUtils.generateReceiptText("Raj", b1));
        StringUtils.isbnComparisonDemo();

        // =========================
        // Tutorial 5 – Section B
        // =========================
        System.out.println("\n=== Tutorial 5: Section B – Shelf Grid & Array Utilities ===");
        String[][] shelves = new String[5][10];
        for (int i = 0; i < 5; i++) Arrays.fill(shelves[i], "");
        ShelfManager.placeOnShelf(shelves, "B001");
        ShelfManager.placeOnShelf(shelves, "B002");
        ShelfManager.printShelves(shelves);

        System.out.println("Most expensive: " + ShelfManager.findMostExpensive(books));
        System.out.println("Before reverse:");
        for (Book b : books) System.out.println(b);
        ShelfManager.reverseInPlace(books);
        System.out.println("After reverse:");
        for (Book b : books) System.out.println(b);

        // =========================
        // Tutorial 5 – Section C
        // =========================
        System.out.println("\n=== Tutorial 5: Section C – ArrayList Catalogue ===");
        CatalogueManager cm = new CatalogueManager();
        cm.addItem(new Book("Clean Code", "Robert Martin", "B001", 850));
        cm.addItem(new Book("Effective Java", "Joshua Bloch", "B002", 950));
        cm.addItem(new Book("Design Patterns", "GoF", "B003", 1200));

        System.out.println("Catalogue:");
        cm.printCatalogue();

        System.out.println("\nSearch results for 'Java':");
        for (var item : cm.searchByTitle("Java")) System.out.println(item);

        System.out.println("\nSorted by price:");
        cm.sortByPrice();
        cm.printCatalogue();

        System.out.println("\nSorted by title:");
        cm.sortByTitle();
        cm.printCatalogue();

        System.out.println("\nRemoving B002...");
        cm.removeItem("B002");
        cm.printCatalogue();

        System.out.println("\nUndo removal:");
        cm.undoRemove();
        cm.printCatalogue();

        // =========================
        // Tutorial 5 – Section D
        // =========================
        System.out.println("\n=== Tutorial 5: Section D – HashSet & HashMap ===");
        BorrowManager bm = new BorrowManager();
        bm.addToIndex(b1);
        bm.addToIndex(b2);

        System.out.println("Borrow B001: " + bm.borrow("B001"));
        System.out.println("Borrow B001 again: " + bm.borrow("B001"));
        bm.returnBook("B001");
        System.out.println("Borrow B001 after return: " + bm.borrow("B001"));

        System.out.println("Find by ISBN B002: " + bm.findByIsbn("B002"));

        String[] borrowLog = {"Clean Code", "Effective Java", "Clean Code", "Clean Code", "Effective Java"};
        bm.mostBorrowedReport(borrowLog);
    }
}
